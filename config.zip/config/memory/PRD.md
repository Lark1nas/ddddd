# FiveM Lynx Panel — PRD

## Problem Statement
User wants a web-based FiveM admin/player panel with Discord login. Upon login, users see their characters; clicking a character shows its vehicles, inventory, money, etc. Admins can edit data.

## User Choices
- Data source: Real FiveM MySQL (ESX Legacy — `users` table with `accounts`, `inventory`, `loadout` JSON)
- Discord login: Real OAuth2 with user-provided keys
- Framework: ESX Legacy
- Admin mode: View + edit enabled
- Design: Dark, modern gaming (GTA/FiveM "Los Santos Control Room")

## Architecture
- Backend: FastAPI + Motor (MongoDB for user cache) + aiomysql (live ESX DB)
- Frontend: React + Tailwind + Shadcn UI
- Auth: Discord OAuth2 → JWT (7-day exp)

## Implemented (2026-02-01)
- Discord OAuth2 full flow (/api/auth/discord/url, /api/auth/discord/callback)
- JWT-based auth, protected routes
- MySQL pool + dynamic schema detection (users.discord / users.identifier)
- List characters, character detail, inventory, vehicles
- Admin: PATCH money, set inventory item, store/release vehicle, delete vehicle
- Landing page (Los Santos hero, Discord login CTA)
- Dashboard (characters bento grid)
- Character detail (tabs: Overview / Inventory / Vehicles)

## Admin Discord ID
- 1073855137157742603

## KNOWN ISSUE
- MySQL server (de2.spaceify.eu:25295) drops connection after handshake → likely IP whitelist on Spaceify panel.
- Pod outbound IP to whitelist: **104.198.214.223**

## P1 / Backlog
- Bulk admin edit (mass inventory / money)
- Audit log of admin actions (stored in Mongo)
- Character activity timeline (last seen, playtime)
- Vehicle image lookup by model

## Update 2026-02-01 — Outbound Bridge Architecture
**Problem:** Spaceify hosting blocks remote MySQL connections (shared hosting firewall, cannot be whitelisted).

**Solution:** Switched to outbound-only bridge pattern:
- New FiveM resource `/app/fivem_resource/lynx_bridge/` (Lua + oxmysql)
- Backend refactored: reads from MongoDB cache, admin edits enqueued as commands
- New endpoints: `POST /api/bridge/sync`, `GET /api/bridge/commands`, `POST /api/bridge/commands/{id}/ack`
- Authenticated via `X-Bridge-Secret` header (token in `.env`)
- Optimistic updates: admin edits mutate Mongo cache immediately + queue command for DB

**Result:** No port opening needed. Works with any FiveM hosting.
