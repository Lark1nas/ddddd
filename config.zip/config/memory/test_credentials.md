# Test Credentials

## Discord OAuth (LynX Panel)
- Client ID: 1456777536263426148
- Redirect URI: https://5a2f908e-b722-4ba6-b77b-da6154c27ce4.preview.emergentagent.com/auth/callback

## Admin Discord ID (auto-granted is_admin)
- 1073855137157742603

## MySQL (FiveM ESX - IP whitelist required)
- Host: de2.spaceify.eu:25295
- DB: s38428_LynX2
- ⚠️  Pod IP 104.198.214.223 must be whitelisted on Spaceify hosting panel
