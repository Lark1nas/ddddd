--[[
  LynX Panel Bridge
  Outbound-only resource: pushes character/vehicle data to the LynX Panel
  and pulls pending admin commands. Requires oxmysql.
]]

local PANEL_URL = GetConvar('lynx_panel_url', 'https://roleplay-panel-2.preview.emergentagent.com')
local BRIDGE_SECRET = GetConvar('lynx_bridge_secret', 'iGw-O0PWnlFkNuttck0EDsg-7zMpBKSoMGfMgw5iPnA')
local SYNC_INTERVAL_MS = 30 * 1000       -- push snapshot every 30s
local POLL_INTERVAL_MS = 5 * 1000        -- poll commands every 5s

local function log(msg)
    print(('[lynx_bridge] %s'):format(msg))
end

local function httpPost(path, body, cb)
    PerformHttpRequest(PANEL_URL .. path, function(status, resp, _)
        cb(status, resp)
    end, 'POST', json.encode(body), {
        ['Content-Type'] = 'application/json',
        ['X-Bridge-Secret'] = BRIDGE_SECRET,
    })
end

local function httpGet(path, cb)
    PerformHttpRequest(PANEL_URL .. path, function(status, resp, _)
        cb(status, resp)
    end, 'GET', '', {
        ['X-Bridge-Secret'] = BRIDGE_SECRET,
    })
end

------------------------------------------------------------
-- SNAPSHOT PUSH
------------------------------------------------------------
local function buildSnapshot(cb)
    MySQL.query('SELECT identifier, firstname, lastname, accounts, job, job_grade, `group`, inventory, loadout, sex, dateofbirth, height, discord FROM users LIMIT 500', {}, function(users)
        MySQL.query('SELECT owner, plate, vehicle, type, job, stored FROM owned_vehicles LIMIT 2000', {}, function(vehicles)
            cb({
                users = users or {},
                vehicles = vehicles or {},
                ts = os.time(),
            })
        end)
    end)
end

local function pushSnapshot()
    buildSnapshot(function(snap)
        httpPost('/api/bridge/sync', snap, function(status, resp)
            if status == 200 then
                log(('snapshot ok: %d users, %d vehicles'):format(#snap.users, #snap.vehicles))
            else
                log(('snapshot FAILED status=%s resp=%s'):format(status, tostring(resp)))
            end
        end)
    end)
end

------------------------------------------------------------
-- COMMAND POLL
------------------------------------------------------------
local function execCommand(cmd, done)
    local t = cmd.type
    local p = cmd.payload or {}

    if t == 'update_money' then
        MySQL.query('SELECT accounts FROM users WHERE identifier = ? LIMIT 1', { p.identifier }, function(rows)
            if not rows or not rows[1] then return done(false, 'not_found') end
            local acc = {}
            if rows[1].accounts and rows[1].accounts ~= '' then
                local ok, decoded = pcall(json.decode, rows[1].accounts)
                if ok and type(decoded) == 'table' then acc = decoded end
            end
            if p.money ~= nil then acc.money = math.floor(tonumber(p.money) or 0) end
            if p.bank ~= nil then acc.bank = math.floor(tonumber(p.bank) or 0) end
            if p.black_money ~= nil then acc.black_money = math.floor(tonumber(p.black_money) or 0) end
            MySQL.update('UPDATE users SET accounts = ? WHERE identifier = ?', { json.encode(acc), p.identifier }, function(affected)
                done(affected and affected >= 0, nil)
            end)
        end)

    elseif t == 'set_inventory' then
        MySQL.query('SELECT inventory FROM users WHERE identifier = ? LIMIT 1', { p.identifier }, function(rows)
            if not rows or not rows[1] then return done(false, 'not_found') end
            local inv = {}
            if rows[1].inventory and rows[1].inventory ~= '' then
                local ok, decoded = pcall(json.decode, rows[1].inventory)
                if ok and type(decoded) == 'table' then inv = decoded end
            end
            local found = false
            for i = #inv, 1, -1 do
                local it = inv[i]
                if type(it) == 'table' and (it.name == p.name or it.item == p.name) then
                    if (tonumber(p.count) or 0) <= 0 then
                        table.remove(inv, i)
                    else
                        it.count = math.floor(tonumber(p.count) or 0)
                        if p.label then it.label = p.label end
                    end
                    found = true
                    break
                end
            end
            if not found and (tonumber(p.count) or 0) > 0 then
                table.insert(inv, { name = p.name, label = p.label or p.name, count = math.floor(tonumber(p.count)) })
            end
            MySQL.update('UPDATE users SET inventory = ? WHERE identifier = ?', { json.encode(inv), p.identifier }, function(affected)
                done(affected and affected >= 0, nil)
            end)
        end)

    elseif t == 'update_vehicle' then
        if p.stored ~= nil then
            MySQL.update('UPDATE owned_vehicles SET stored = ? WHERE plate = ?', { p.stored and 1 or 0, p.plate }, function(affected)
                done(affected and affected >= 0, nil)
            end)
        else
            done(true, nil)
        end

    elseif t == 'delete_vehicle' then
        MySQL.update('DELETE FROM owned_vehicles WHERE plate = ?', { p.plate }, function(affected)
            done(affected and affected >= 0, nil)
        end)

    elseif t == 'create_vehicle' then
        local hash = GetHashKey(p.model)
        local vehicle_json = json.encode({ model = hash, plate = p.plate })
        MySQL.insert('INSERT INTO owned_vehicles (owner, plate, vehicle, type, stored) VALUES (?, ?, ?, ?, 1)',
            { p.identifier, p.plate, vehicle_json, p.type or 'car' }, function(id)
                done(id and id > 0, nil)
            end)

    elseif t == 'update_plate' then
        MySQL.update('UPDATE owned_vehicles SET plate = ? WHERE plate = ?', { p.new_plate, p.old_plate }, function(affected)
            done(affected and affected >= 0, nil)
        end)

    elseif t == 'update_job' then
        MySQL.update('UPDATE users SET job = ?, job_grade = ? WHERE identifier = ?', { p.job, p.job_grade or 0, p.identifier }, function(affected)
            done(affected and affected >= 0, nil)
        end)

    elseif t == 'update_profile' then
        local sets, params = {}, {}
        if p.firstname ~= nil then table.insert(sets, 'firstname = ?') table.insert(params, p.firstname) end
        if p.lastname ~= nil then table.insert(sets, 'lastname = ?') table.insert(params, p.lastname) end
        if p.dateofbirth ~= nil then table.insert(sets, 'dateofbirth = ?') table.insert(params, p.dateofbirth) end
        if p.sex ~= nil then table.insert(sets, 'sex = ?') table.insert(params, p.sex) end
        if p.height ~= nil then table.insert(sets, 'height = ?') table.insert(params, p.height) end
        if #sets == 0 then return done(false, 'no_fields') end
        table.insert(params, p.identifier)
        local sql = ('UPDATE users SET %s WHERE identifier = ?'):format(table.concat(sets, ', '))
        MySQL.update(sql, params, function(affected)
            done(affected and affected >= 0, nil)
        end)

    else
        done(false, 'unknown_type')
    end
end

local function pollCommands()
    httpGet('/api/bridge/commands', function(status, resp)
        if status ~= 200 or not resp or resp == '' then return end
        local ok, data = pcall(json.decode, resp)
        if not ok or type(data) ~= 'table' or not data.commands then return end
        for _, cmd in ipairs(data.commands) do
            execCommand(cmd, function(success, err)
                httpPost('/api/bridge/commands/' .. cmd.id .. '/ack', {
                    success = success, error = err,
                }, function(_, _) end)
                if success then
                    log(('cmd %s done'):format(cmd.type))
                    -- push snapshot immediately so panel reflects change
                    pushSnapshot()
                else
                    log(('cmd %s FAILED: %s'):format(cmd.type, tostring(err)))
                end
            end)
        end
    end)
end

------------------------------------------------------------
-- SCHEDULERS
------------------------------------------------------------
CreateThread(function()
    Wait(5000)  -- wait for mysql ready
    log(('starting bridge → %s'):format(PANEL_URL))
    pushSnapshot()
    while true do
        Wait(SYNC_INTERVAL_MS)
        pushSnapshot()
    end
end)

CreateThread(function()
    Wait(8000)
    while true do
        pollCommands()
        Wait(POLL_INTERVAL_MS)
    end
end)

RegisterCommand('lynxpush', function(source)
    if source == 0 then
        pushSnapshot()
        log('manual push triggered')
    end
end, true)
