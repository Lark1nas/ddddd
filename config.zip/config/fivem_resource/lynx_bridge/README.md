# LynX Panel Bridge — įdiegimas

FiveM resource, kuris sinchronizuoja jūsų ESX Legacy duomenų bazę su LynX Panel **be jokio porto atidarymo**.

## Reikalavimai
- ESX Legacy
- **oxmysql** (standartinė ESX Legacy MySQL biblioteka)
- FXServer (bet kokia versija)

## Įdiegimas

### 1. Įkelkite resource
Nukopijuokite aplanką `lynx_bridge` į savo serverio `resources/` aplanką:
```
resources/
└── lynx_bridge/
    ├── fxmanifest.lua
    └── server.lua
```

### 2. Pridėkite į `server.cfg`

Pridėkite šias eilutes **po `oxmysql` paleidimo**:

```cfg
# LynX Panel Bridge
set lynx_panel_url "https://roleplay-panel-2.preview.emergentagent.com"
set lynx_bridge_secret "iGw-O0PWnlFkNuttck0EDsg-7zMpBKSoMGfMgw5iPnA"
ensure lynx_bridge
```

> ⚠️ **SVARBU:** `lynx_bridge_secret` turi sutapti su `BRIDGE_SECRET` panelės `backend/.env` — jau sugeneravau automatiškai, tiesiog nukopijuokite kaip yra.

### 3. Paleiskite / restartuokite serverį

Arba gyvai konsolėje:
```
refresh
ensure lynx_bridge
```

### 4. Patikrinimas

Konsolėje turite matyti:
```
[lynx_bridge] starting bridge → https://roleplay-panel-2.preview.emergentagent.com
[lynx_bridge] snapshot ok: 5 users, 12 vehicles
```

Ir panelė `/api/health` turi rodyti `bridge_connected: true`.

## Kaip tai veikia

- **Kas 30 sek** resource siunčia visų žaidėjų + transporto snapshot'ą į panelę (outbound HTTPS).
- **Kas 5 sek** resource klausia panelės ar yra admin komandų (money update, inventory edit, vehicle delete/toggle, **plate change, job change**).
- Kai komanda įvykdoma — iš karto siunčiamas naujas snapshot, kad panelė parodytų atnaujintus duomenis.

## Palaikomos admin komandos
- `update_money` — cash / bank / black money
- `set_inventory` — pridėti / pakeisti / pašalinti item
- `update_vehicle` — store/release
- `delete_vehicle` — ištrinti transporto priemonę
- `update_plate` — pakeisti numerį
- `update_job` — pakeisti darbą + grade

## Komandos

Serverio konsolėje:
- `lynxpush` — priverstinai siųsti snapshot'ą nelaukiant 30 sek intervalo.

## Saugumas

- Visos užklausos autentifikuojamos `X-Bridge-Secret` antraštė.
- Slaptažodis yra 43 simbolių token'as. Jei įtariate, kad jis paviešintas — sugeneruokite naują:
  1. `backend/.env` → `BRIDGE_SECRET="naujas-slaptažodis"`
  2. `server.cfg` → `set lynx_bridge_secret "naujas-slaptažodis"`
  3. Restart abi pusės.
