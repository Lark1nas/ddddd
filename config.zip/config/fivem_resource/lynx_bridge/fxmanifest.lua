fx_version 'cerulean'
game 'gta5'

name 'lynx_bridge'
description 'LynX Panel outbound bridge for ESX servers'
author 'LynX'
version '1.0.0'

server_script 'server.lua'

server_exports {}
