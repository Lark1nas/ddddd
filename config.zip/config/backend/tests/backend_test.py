"""Backend API tests for FiveM Lynx Panel"""
import os
import pytest
import requests

BASE_URL = "https://roleplay-panel-2.preview.emergentagent.com"
DISCORD_CLIENT_ID = "1456777536263426148"


@pytest.fixture
def client():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


# --- Root & Health ---
class TestHealth:
    def test_root(self, client):
        r = client.get(f"{BASE_URL}/api/")
        assert r.status_code == 200
        data = r.json()
        assert "message" in data
        assert "version" in data

    def test_health_shape(self, client):
        r = client.get(f"{BASE_URL}/api/health")
        assert r.status_code == 200
        data = r.json()
        assert "status" in data
        assert "mysql_connected" in data
        assert isinstance(data["mysql_connected"], bool)


# --- Discord OAuth ---
class TestDiscordAuth:
    def test_discord_url(self, client):
        r = client.get(f"{BASE_URL}/api/auth/discord/url")
        assert r.status_code == 200
        data = r.json()
        assert "url" in data
        assert "discord.com" in data["url"]
        assert f"client_id={DISCORD_CLIENT_ID}" in data["url"]
        assert "response_type=code" in data["url"]
        assert "scope=identify" in data["url"]

    def test_discord_callback_invalid_code(self, client):
        r = client.post(
            f"{BASE_URL}/api/auth/discord/callback",
            json={"code": "INVALID_CODE_XYZ"},
        )
        assert r.status_code == 400


# --- Protected routes ---
class TestProtected:
    def test_me_no_token(self, client):
        r = client.get(f"{BASE_URL}/api/auth/me")
        assert r.status_code in (401, 403)

    def test_characters_no_token(self, client):
        r = client.get(f"{BASE_URL}/api/characters")
        assert r.status_code in (401, 403)

    def test_characters_forged_jwt(self, client):
        bad = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmYWtlIn0.invalid_signature_here"
        r = client.get(
            f"{BASE_URL}/api/characters",
            headers={"Authorization": f"Bearer {bad}"},
        )
        assert r.status_code == 401
