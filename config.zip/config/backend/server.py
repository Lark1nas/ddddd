import os
import json
import uuid
import logging
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Any

import httpx
import jwt
from fastapi import FastAPI, APIRouter, HTTPException, Depends, Header, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# --- Config ---
MONGO_URL = os.environ['MONGO_URL']
DB_NAME = os.environ['DB_NAME']
DISCORD_CLIENT_ID = os.environ['DISCORD_CLIENT_ID']
DISCORD_CLIENT_SECRET = os.environ['DISCORD_CLIENT_SECRET']
DISCORD_REDIRECT_URI = os.environ['DISCORD_REDIRECT_URI']
JWT_SECRET = os.environ['JWT_SECRET']
BRIDGE_SECRET = os.environ['BRIDGE_SECRET']
DISCORD_BOT_TOKEN = os.environ.get('DISCORD_BOT_TOKEN', '').strip()
DISCORD_GUILD_ID = os.environ.get('DISCORD_GUILD_ID', '').strip()
STAFF_ROLE_KEYWORDS = [
    k.strip().lower() for k in os.environ.get('STAFF_ROLE_KEYWORDS', '').split(',') if k.strip()
]
SUPER_ADMIN_ROLE_KEYWORDS = [
    k.strip().lower() for k in os.environ.get('SUPER_ADMIN_ROLE_KEYWORDS', 'savininkas').split(',') if k.strip()
]
ADMIN_DISCORD_IDS = set(x.strip() for x in os.environ.get('ADMIN_DISCORD_IDS', '').split(',') if x.strip())

ALL_PERMISSIONS = [
    "edit_money",
    "edit_inventory",
    "edit_job",
    "edit_profile",
    "edit_vehicles",
    "change_plates",
    "delete_vehicles",
    "give_vehicle",
]

DISCORD_API = "https://discord.com/api/v10"

mongo_client = AsyncIOMotorClient(MONGO_URL)
db = mongo_client[DB_NAME]

app = FastAPI(title="FiveM Lynx Panel")
api_router = APIRouter(prefix="/api")
security = HTTPBearer(auto_error=False)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("fivem-panel")


# --- Auth ---
class AuthUser(BaseModel):
    discord_id: str
    username: str
    avatar: Optional[str] = None
    is_admin: bool = False
    is_super: bool = False
    permissions: List[str] = []


def create_jwt(user: AuthUser) -> str:
    return jwt.encode({
        "sub": user.discord_id, "username": user.username, "avatar": user.avatar,
        "is_admin": user.is_admin, "is_super": user.is_super,
        "permissions": user.permissions,
        "exp": datetime.now(timezone.utc) + timedelta(days=7),
    }, JWT_SECRET, algorithm="HS256")


async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> AuthUser:
    if credentials is None:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=["HS256"])
        return AuthUser(
            discord_id=payload["sub"], username=payload["username"],
            avatar=payload.get("avatar"),
            is_admin=payload.get("is_admin", False),
            is_super=payload.get("is_super", False),
            permissions=payload.get("permissions", []),
        )
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")


def require_admin(user: AuthUser = Depends(get_current_user)) -> AuthUser:
    if not user.is_admin:
        raise HTTPException(status_code=403, detail="Admin only")
    return user


def require_super(user: AuthUser = Depends(get_current_user)) -> AuthUser:
    if not user.is_super:
        raise HTTPException(status_code=403, detail="Only Savininkas / Co. Savininkas can perform this action")
    return user


def require_permission(perm: str):
    async def checker(user: AuthUser = Depends(get_current_user)) -> AuthUser:
        if user.is_super or perm in user.permissions:
            return user
        raise HTTPException(status_code=403, detail=f"Missing permission: {perm}")
    return checker


async def require_bridge(x_bridge_secret: Optional[str] = Header(None, alias="X-Bridge-Secret")):
    if x_bridge_secret != BRIDGE_SECRET:
        raise HTTPException(status_code=401, detail="Invalid bridge secret")
    return True


async def is_admin_discord(discord_id: str) -> bool:
    if discord_id in ADMIN_DISCORD_IDS:
        return True
    found = await db.admins.find_one({"discord_id": discord_id})
    return found is not None


async def fetch_user_guild_roles(discord_id: str) -> List[str]:
    """Return list of role NAMES for given discord user in guild."""
    if not DISCORD_BOT_TOKEN or not DISCORD_GUILD_ID:
        return []
    headers = {"Authorization": f"Bot {DISCORD_BOT_TOKEN}"}
    async with httpx.AsyncClient(timeout=15.0, headers=headers) as client:
        mr = await client.get(f"{DISCORD_API}/guilds/{DISCORD_GUILD_ID}/members/{discord_id}")
        if mr.status_code != 200:
            return []
        member = mr.json()
        role_ids = member.get("roles", [])
        if not role_ids:
            return []
        rr = await client.get(f"{DISCORD_API}/guilds/{DISCORD_GUILD_ID}/roles")
        if rr.status_code != 200:
            return []
        roles_by_id = {r["id"]: r["name"] for r in rr.json()}
    return [roles_by_id[rid] for rid in role_ids if rid in roles_by_id]


async def resolve_access(discord_id: str) -> dict:
    """Resolve is_admin / is_super / permissions for a Discord user."""
    roles = await fetch_user_guild_roles(discord_id)
    roles_lower = [r.lower() for r in roles]
    is_super = any(any(kw in name for kw in SUPER_ADMIN_ROLE_KEYWORDS) for name in roles_lower)
    if discord_id in ADMIN_DISCORD_IDS:
        is_super = True

    if is_super:
        return {"is_super": True, "is_admin": True, "permissions": list(ALL_PERMISSIONS), "roles": roles}

    admin_doc = await db.admins.find_one({"discord_id": discord_id}, {"_id": 0})
    if admin_doc:
        perms = admin_doc.get("permissions") or list(ALL_PERMISSIONS)
        return {"is_super": False, "is_admin": True, "permissions": perms, "roles": roles}

    return {"is_super": False, "is_admin": False, "permissions": [], "roles": roles}


@app.on_event("startup")
async def seed_admins():
    for did in ADMIN_DISCORD_IDS:
        await db.admins.update_one(
            {"discord_id": did},
            {"$setOnInsert": {
                "discord_id": did, "seeded": True,
                "permissions": list(ALL_PERMISSIONS),
                "added_at": datetime.now(timezone.utc).isoformat(),
                "added_by": "env",
            }},
            upsert=True,
        )


# --- Helpers ---
def parse_json_field(val: Any, default: Any):
    if val is None:
        return default
    if isinstance(val, (dict, list)):
        return val
    if isinstance(val, (bytes, bytearray)):
        try:
            val = val.decode("utf-8")
        except Exception:
            return default
    if isinstance(val, str):
        try:
            return json.loads(val)
        except Exception:
            return default
    return default


def money_from_accounts(accounts_json: Any) -> dict:
    acc = parse_json_field(accounts_json, {})
    if isinstance(acc, dict):
        return {
            "money": int(acc.get("money", 0) or 0),
            "bank": int(acc.get("bank", 0) or 0),
            "black_money": int(acc.get("black_money", 0) or 0),
        }
    return {"money": 0, "bank": 0, "black_money": 0}


def user_matches_discord(user_row: dict, discord_id: str) -> bool:
    """Match a fivem_users row against a Discord snowflake ID.
    Supports:
      - users.discord column stored as raw snowflake: "1185675673797402675"
      - users.discord column stored as "discord:1185675673797402675"
      - users.identifier containing "discord:1185675673797402675"
    """
    if not discord_id:
        return False
    did = str(discord_id).strip()
    discord_val = user_row.get("discord")
    if discord_val is not None:
        dv = str(discord_val).strip()
        if dv == did:
            return True
        if dv == f"discord:{did}":
            return True
        if did in dv:
            return True
    identifier = str(user_row.get("identifier", ""))
    if f"discord:{did}" in identifier:
        return True
    return False


# --- Discord OAuth ---
@api_router.get("/auth/discord/url")
async def discord_auth_url():
    from urllib.parse import urlencode
    params = {
        "client_id": DISCORD_CLIENT_ID, "redirect_uri": DISCORD_REDIRECT_URI,
        "response_type": "code", "scope": "identify",
    }
    return {"url": f"https://discord.com/api/oauth2/authorize?{urlencode(params)}"}


class DiscordCallbackBody(BaseModel):
    code: str


@api_router.post("/auth/discord/callback")
async def discord_callback(body: DiscordCallbackBody):
    async with httpx.AsyncClient(timeout=15.0) as client:
        token_resp = await client.post(
            "https://discord.com/api/oauth2/token",
            data={
                "client_id": DISCORD_CLIENT_ID, "client_secret": DISCORD_CLIENT_SECRET,
                "grant_type": "authorization_code", "code": body.code,
                "redirect_uri": DISCORD_REDIRECT_URI,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        if token_resp.status_code != 200:
            logger.error(f"Discord token error: {token_resp.text}")
            raise HTTPException(status_code=400, detail="Failed to exchange code")
        access_token = token_resp.json()["access_token"]

        user_resp = await client.get(
            "https://discord.com/api/users/@me",
            headers={"Authorization": f"Bearer {access_token}"},
        )
        if user_resp.status_code != 200:
            raise HTTPException(status_code=400, detail="Failed to fetch Discord user")
        u = user_resp.json()

    discord_id = u["id"]
    username = u.get("global_name") or u.get("username") or "User"
    avatar = (
        f"https://cdn.discordapp.com/avatars/{discord_id}/{u['avatar']}.png"
        if u.get("avatar") else None
    )
    access = await resolve_access(discord_id)

    await db.users.update_one(
        {"discord_id": discord_id},
        {"$set": {
            "discord_id": discord_id, "username": username, "avatar": avatar,
            "is_admin": access["is_admin"], "is_super": access["is_super"],
            "permissions": access["permissions"],
            "last_login": datetime.now(timezone.utc).isoformat(),
        }},
        upsert=True,
    )

    auth_user = AuthUser(
        discord_id=discord_id, username=username, avatar=avatar,
        is_admin=access["is_admin"], is_super=access["is_super"],
        permissions=access["permissions"],
    )
    return {"token": create_jwt(auth_user), "user": auth_user.model_dump()}


@api_router.get("/auth/me")
async def me(user: AuthUser = Depends(get_current_user)):
    return user.model_dump()


@api_router.post("/auth/refresh")
async def refresh_token(user: AuthUser = Depends(get_current_user)):
    """Re-resolve access from Discord roles and issue a new JWT."""
    access = await resolve_access(user.discord_id)
    updated = AuthUser(
        discord_id=user.discord_id, username=user.username, avatar=user.avatar,
        is_admin=access["is_admin"], is_super=access["is_super"],
        permissions=access["permissions"],
    )
    return {"token": create_jwt(updated), "user": updated.model_dump()}


# --- Bridge endpoints (called by FiveM resource) ---
class BridgeSyncBody(BaseModel):
    users: List[dict] = []
    vehicles: List[dict] = []
    ts: Optional[int] = None


@api_router.post("/bridge/sync")
async def bridge_sync(body: BridgeSyncBody, _: bool = Depends(require_bridge)):
    now = datetime.now(timezone.utc).isoformat()
    # replace users
    await db.fivem_users.delete_many({})
    if body.users:
        for u in body.users:
            u["_synced_at"] = now
        await db.fivem_users.insert_many(body.users)
    # replace vehicles
    await db.fivem_vehicles.delete_many({})
    if body.vehicles:
        for v in body.vehicles:
            v["_synced_at"] = now
        await db.fivem_vehicles.insert_many(body.vehicles)
    await db.bridge_state.update_one(
        {"_id": "state"},
        {"$set": {"last_sync": now, "users_count": len(body.users), "vehicles_count": len(body.vehicles)}},
        upsert=True,
    )
    logger.info(f"Bridge sync: {len(body.users)} users, {len(body.vehicles)} vehicles")
    return {"ok": True}


@api_router.get("/bridge/commands")
async def bridge_commands(_: bool = Depends(require_bridge)):
    cursor = db.fivem_commands.find({"status": "pending"}, {"_id": 0}).limit(50)
    cmds = await cursor.to_list(50)
    # mark as in-flight
    ids = [c["id"] for c in cmds]
    if ids:
        await db.fivem_commands.update_many(
            {"id": {"$in": ids}, "status": "pending"},
            {"$set": {"status": "in_flight", "sent_at": datetime.now(timezone.utc).isoformat()}},
        )
    return {"commands": cmds}


class CommandAck(BaseModel):
    success: bool
    error: Optional[str] = None


@api_router.post("/bridge/commands/{cmd_id}/ack")
async def bridge_ack(cmd_id: str, body: CommandAck, _: bool = Depends(require_bridge)):
    await db.fivem_commands.update_one(
        {"id": cmd_id},
        {"$set": {
            "status": "done" if body.success else "failed",
            "error": body.error,
            "acked_at": datetime.now(timezone.utc).isoformat(),
        }},
    )
    return {"ok": True}


# --- Character read endpoints (from Mongo cache) ---
async def _char_filter(user: AuthUser) -> Optional[List[str]]:
    """Returns list of allowed identifiers, or None = all (admin)."""
    if user.is_admin:
        return None
    cursor = db.fivem_users.find({}, {"_id": 0})
    allowed = []
    async for row in cursor:
        if user_matches_discord(row, user.discord_id):
            allowed.append(row.get("identifier"))
    return allowed


@api_router.get("/characters")
async def list_characters(user: AuthUser = Depends(get_current_user)):
    allowed = await _char_filter(user)
    q = {} if allowed is None else {"identifier": {"$in": allowed}}
    rows = await db.fivem_users.find(q, {"_id": 0}).to_list(500)
    result = []
    for r in rows:
        money = money_from_accounts(r.get("accounts"))
        result.append({
            "identifier": r.get("identifier"),
            "firstname": r.get("firstname") or "",
            "lastname": r.get("lastname") or "",
            "job": r.get("job") or "unemployed",
            "job_grade": r.get("job_grade") or 0,
            "group": r.get("group") or "user",
            "mine": user_matches_discord(r, user.discord_id),
            **money,
        })
    return result


async def _fetch_character(identifier: str, user: AuthUser) -> dict:
    row = await db.fivem_users.find_one({"identifier": identifier}, {"_id": 0})
    if not row:
        raise HTTPException(status_code=404, detail="Character not found (bridge may not have synced yet)")
    if not user.is_admin and not user_matches_discord(row, user.discord_id):
        raise HTTPException(status_code=403, detail="Access denied to this character")
    return row


@api_router.get("/characters/{identifier:path}/inventory")
async def get_inventory(identifier: str, user: AuthUser = Depends(get_current_user)):
    row = await _fetch_character(identifier, user)
    inv = parse_json_field(row.get("inventory"), [])
    loadout = parse_json_field(row.get("loadout"), [])
    items = []
    if isinstance(inv, list):
        for it in inv:
            if isinstance(it, dict):
                items.append({
                    "name": it.get("name") or it.get("item") or "unknown",
                    "label": it.get("label") or it.get("name") or "Unknown",
                    "count": int(it.get("count", it.get("amount", 1)) or 0),
                })
    elif isinstance(inv, dict):
        for k, v in inv.items():
            items.append({"name": k, "label": k, "count": int(v or 0)})
    weapons = []
    if isinstance(loadout, list):
        for w in loadout:
            if isinstance(w, dict):
                weapons.append({
                    "name": w.get("name", "unknown"),
                    "label": w.get("label", w.get("name", "Weapon")),
                    "ammo": int(w.get("ammo", 0) or 0),
                })
    return {"items": items, "weapons": weapons}


@api_router.get("/characters/{identifier:path}/vehicles")
async def get_vehicles(identifier: str, user: AuthUser = Depends(get_current_user)):
    await _fetch_character(identifier, user)
    rows = await db.fivem_vehicles.find({"owner": identifier}, {"_id": 0}).to_list(500)
    vehicles = []
    for r in rows:
        veh = parse_json_field(r.get("vehicle"), {})
        model = None
        if isinstance(veh, dict):
            model = veh.get("model") or veh.get("modelName")
        vehicles.append({
            "plate": (r.get("plate") or "").strip(),
            "model": str(model) if model is not None else "unknown",
            "type": r.get("type") or "car",
            "job": r.get("job"),
            "stored": bool(r.get("stored", 1)),
        })
    return {"vehicles": vehicles}


@api_router.get("/characters/{identifier:path}")
async def get_character(identifier: str, user: AuthUser = Depends(get_current_user)):
    row = await _fetch_character(identifier, user)
    money = money_from_accounts(row.get("accounts"))
    return {
        "identifier": row.get("identifier"),
        "firstname": row.get("firstname") or "",
        "lastname": row.get("lastname") or "",
        "job": row.get("job") or "unemployed",
        "job_grade": row.get("job_grade") or 0,
        "group": row.get("group") or "user",
        "sex": row.get("sex"),
        "dateofbirth": row.get("dateofbirth"),
        "height": row.get("height"),
        **money,
    }


# --- Admin write endpoints (enqueue commands) ---
async def _enqueue(cmd_type: str, payload: dict, actor: AuthUser) -> str:
    cmd_id = str(uuid.uuid4())
    await db.fivem_commands.insert_one({
        "id": cmd_id,
        "type": cmd_type,
        "payload": payload,
        "status": "pending",
        "actor_discord_id": actor.discord_id,
        "actor_username": actor.username,
        "created_at": datetime.now(timezone.utc).isoformat(),
    })
    # optimistic local mutation so UI reflects change immediately
    return cmd_id


class MoneyUpdate(BaseModel):
    money: Optional[int] = None
    bank: Optional[int] = None
    black_money: Optional[int] = None


@api_router.patch("/characters/{identifier:path}/money")
async def update_money(identifier: str, body: MoneyUpdate, user: AuthUser = Depends(require_permission("edit_money"))):
    # optimistic update in mongo cache
    row = await db.fivem_users.find_one({"identifier": identifier})
    if row:
        acc = parse_json_field(row.get("accounts"), {}) or {}
        if not isinstance(acc, dict):
            acc = {}
        if body.money is not None:
            acc["money"] = int(body.money)
        if body.bank is not None:
            acc["bank"] = int(body.bank)
        if body.black_money is not None:
            acc["black_money"] = int(body.black_money)
        await db.fivem_users.update_one({"identifier": identifier}, {"$set": {"accounts": json.dumps(acc)}})
    cmd_id = await _enqueue("update_money", {
        "identifier": identifier,
        "money": body.money, "bank": body.bank, "black_money": body.black_money,
    }, user)
    return {"success": True, "command_id": cmd_id}


class InventoryItemUpdate(BaseModel):
    name: str
    label: Optional[str] = None
    count: int


@api_router.post("/characters/{identifier:path}/inventory/set")
async def set_inventory_item(identifier: str, body: InventoryItemUpdate, user: AuthUser = Depends(require_permission("edit_inventory"))):
    row = await db.fivem_users.find_one({"identifier": identifier})
    if row:
        inv = parse_json_field(row.get("inventory"), []) or []
        if not isinstance(inv, list):
            inv = []
        found = False
        for it in list(inv):
            if isinstance(it, dict) and (it.get("name") == body.name or it.get("item") == body.name):
                if body.count <= 0:
                    inv.remove(it)
                else:
                    it["count"] = body.count
                    if body.label:
                        it["label"] = body.label
                found = True
                break
        if not found and body.count > 0:
            inv.append({"name": body.name, "label": body.label or body.name, "count": body.count})
        await db.fivem_users.update_one({"identifier": identifier}, {"$set": {"inventory": json.dumps(inv)}})
    cmd_id = await _enqueue("set_inventory", {
        "identifier": identifier, "name": body.name,
        "label": body.label, "count": body.count,
    }, user)
    return {"success": True, "command_id": cmd_id}


class VehicleUpdate(BaseModel):
    stored: Optional[bool] = None


@api_router.patch("/vehicles/{plate}")
async def update_vehicle(plate: str, body: VehicleUpdate, user: AuthUser = Depends(require_permission("edit_vehicles"))):
    if body.stored is not None:
        await db.fivem_vehicles.update_one({"plate": plate}, {"$set": {"stored": 1 if body.stored else 0}})
    cmd_id = await _enqueue("update_vehicle", {"plate": plate, "stored": body.stored}, user)
    return {"success": True, "command_id": cmd_id}


@api_router.delete("/vehicles/{plate}")
async def delete_vehicle(plate: str, user: AuthUser = Depends(require_permission("delete_vehicles"))):
    await db.fivem_vehicles.delete_one({"plate": plate})
    cmd_id = await _enqueue("delete_vehicle", {"plate": plate}, user)
    return {"success": True, "command_id": cmd_id}


class PlateUpdate(BaseModel):
    new_plate: str


@api_router.patch("/vehicles/{plate}/plate")
async def update_plate(plate: str, body: PlateUpdate, user: AuthUser = Depends(require_permission("change_plates"))):
    new_plate = body.new_plate.strip().upper()
    if not new_plate or len(new_plate) > 8:
        raise HTTPException(status_code=400, detail="Invalid plate (1-8 chars)")
    existing = await db.fivem_vehicles.find_one({"plate": new_plate})
    if existing and existing.get("plate") != plate:
        raise HTTPException(status_code=409, detail="Plate already in use")
    await db.fivem_vehicles.update_one({"plate": plate}, {"$set": {"plate": new_plate}})
    cmd_id = await _enqueue("update_plate", {"old_plate": plate, "new_plate": new_plate}, user)
    return {"success": True, "command_id": cmd_id, "new_plate": new_plate}


class JobUpdate(BaseModel):
    job: str
    job_grade: int = 0


@api_router.patch("/characters/{identifier:path}/job")
async def update_job(identifier: str, body: JobUpdate, user: AuthUser = Depends(require_permission("edit_job"))):
    job = body.job.strip().lower()
    if not job:
        raise HTTPException(status_code=400, detail="Job name required")
    await db.fivem_users.update_one(
        {"identifier": identifier},
        {"$set": {"job": job, "job_grade": int(body.job_grade)}},
    )
    cmd_id = await _enqueue("update_job", {
        "identifier": identifier, "job": job, "job_grade": int(body.job_grade),
    }, user)
    return {"success": True, "command_id": cmd_id}


class ProfileUpdate(BaseModel):
    firstname: Optional[str] = None
    lastname: Optional[str] = None
    dateofbirth: Optional[str] = None
    sex: Optional[str] = None
    height: Optional[int] = None


@api_router.patch("/characters/{identifier:path}/profile")
async def update_profile(identifier: str, body: ProfileUpdate, user: AuthUser = Depends(require_permission("edit_profile"))):
    updates: dict = {}
    payload: dict = {"identifier": identifier}
    if body.firstname is not None:
        fn = body.firstname.strip()
        if not fn:
            raise HTTPException(status_code=400, detail="Firstname cannot be empty")
        updates["firstname"] = fn
        payload["firstname"] = fn
    if body.lastname is not None:
        ln = body.lastname.strip()
        if not ln:
            raise HTTPException(status_code=400, detail="Lastname cannot be empty")
        updates["lastname"] = ln
        payload["lastname"] = ln
    if body.dateofbirth is not None:
        updates["dateofbirth"] = body.dateofbirth.strip()
        payload["dateofbirth"] = body.dateofbirth.strip()
    if body.sex is not None:
        s = body.sex.strip().upper()
        if s not in ("M", "F", ""):
            raise HTTPException(status_code=400, detail="Sex must be M or F")
        updates["sex"] = s
        payload["sex"] = s
    if body.height is not None:
        h = int(body.height)
        if h < 100 or h > 250:
            raise HTTPException(status_code=400, detail="Height must be between 100 and 250 cm")
        updates["height"] = h
        payload["height"] = h
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    await db.fivem_users.update_one({"identifier": identifier}, {"$set": updates})
    cmd_id = await _enqueue("update_profile", payload, user)
    return {"success": True, "command_id": cmd_id}


# --- Admin management ---
@api_router.get("/admins")
async def list_admins(user: AuthUser = Depends(require_admin)):
    rows = await db.admins.find({}, {"_id": 0}).to_list(200)
    return rows


@api_router.get("/admins/permissions")
async def list_permissions(user: AuthUser = Depends(require_admin)):
    return {"permissions": ALL_PERMISSIONS}


class AddAdminBody(BaseModel):
    discord_id: str
    note: Optional[str] = None
    permissions: Optional[List[str]] = None


@api_router.post("/admins")
async def add_admin(body: AddAdminBody, user: AuthUser = Depends(require_super)):
    did = body.discord_id.strip()
    if not did.isdigit() or len(did) < 15 or len(did) > 25:
        raise HTTPException(status_code=400, detail="Invalid Discord ID (must be numeric snowflake)")
    perms = body.permissions if body.permissions is not None else list(ALL_PERMISSIONS)
    # filter to valid perms
    perms = [p for p in perms if p in ALL_PERMISSIONS]
    await db.admins.update_one(
        {"discord_id": did},
        {"$set": {
            "discord_id": did, "note": body.note,
            "permissions": perms,
            "added_at": datetime.now(timezone.utc).isoformat(),
            "added_by": user.discord_id,
        }},
        upsert=True,
    )
    return {"success": True, "discord_id": did, "permissions": perms}


class UpdateAdminBody(BaseModel):
    permissions: Optional[List[str]] = None
    note: Optional[str] = None


@api_router.patch("/admins/{discord_id}")
async def update_admin(discord_id: str, body: UpdateAdminBody, user: AuthUser = Depends(require_super)):
    existing = await db.admins.find_one({"discord_id": discord_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Admin not found")
    updates = {}
    if body.permissions is not None:
        updates["permissions"] = [p for p in body.permissions if p in ALL_PERMISSIONS]
    if body.note is not None:
        updates["note"] = body.note
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    await db.admins.update_one({"discord_id": discord_id}, {"$set": updates})
    return {"success": True}


@api_router.delete("/admins/{discord_id}")
async def remove_admin(discord_id: str, user: AuthUser = Depends(require_super)):
    if discord_id in ADMIN_DISCORD_IDS:
        raise HTTPException(status_code=400, detail="Cannot remove root admin (seeded via .env)")
    if discord_id == user.discord_id:
        raise HTTPException(status_code=400, detail="You cannot remove yourself")
    result = await db.admins.delete_one({"discord_id": discord_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Admin not found")
    return {"success": True}


# --- Debug ---
@api_router.get("/debug/whoami")
async def debug_whoami(user: AuthUser = Depends(get_current_user)):
    total = await db.fivem_users.count_documents({})
    matched = 0
    samples = []
    cursor = db.fivem_users.find({}, {"_id": 0, "identifier": 1, "discord": 1, "firstname": 1, "lastname": 1})
    async for row in cursor:
        if user_matches_discord(row, user.discord_id):
            matched += 1
        if len(samples) < 5:
            samples.append({
                "identifier": row.get("identifier"),
                "discord": row.get("discord"),
                "name": f"{row.get('firstname', '')} {row.get('lastname', '')}".strip(),
            })
    return {
        "your_discord_id": user.discord_id,
        "your_username": user.username,
        "is_admin": user.is_admin,
        "total_users_in_db": total,
        "matched_characters": matched,
        "sample_rows": samples,
    }


# --- Discord Team (public) ---
_team_cache: dict = {"ts": 0, "data": []}
TEAM_CACHE_TTL = 300  # 5 min


def _role_color_hex(integer_color: int) -> Optional[str]:
    if not integer_color:
        return None
    return f"#{integer_color:06x}"


async def fetch_discord_team() -> List[dict]:
    if not DISCORD_BOT_TOKEN or not DISCORD_GUILD_ID:
        return []
    headers = {"Authorization": f"Bot {DISCORD_BOT_TOKEN}"}
    async with httpx.AsyncClient(timeout=20.0, headers=headers) as client:
        # Roles
        r = await client.get(f"{DISCORD_API}/guilds/{DISCORD_GUILD_ID}/roles")
        if r.status_code != 200:
            logger.error(f"Discord roles fetch failed: {r.status_code} {r.text[:200]}")
            return []
        roles_raw = r.json()
        roles_by_id = {
            role["id"]: {
                "id": role["id"],
                "name": role["name"],
                "color": _role_color_hex(role.get("color", 0)),
                "position": role.get("position", 0),
            }
            for role in roles_raw if role["name"] != "@everyone"
        }
        # Determine which role IDs are "staff"
        staff_role_ids = set()
        for rid, r_ in roles_by_id.items():
            name_lower = r_["name"].lower()
            if any(kw in name_lower for kw in STAFF_ROLE_KEYWORDS):
                staff_role_ids.add(rid)
        if not staff_role_ids:
            logger.warning("No staff roles matched keywords; returning empty team")
            return []

        # Members (paginated, up to 1000)
        members: list = []
        after = "0"
        for _ in range(2):  # up to 2000 members
            resp = await client.get(
                f"{DISCORD_API}/guilds/{DISCORD_GUILD_ID}/members",
                params={"limit": 1000, "after": after},
            )
            if resp.status_code != 200:
                logger.error(f"Members fetch failed: {resp.status_code} {resp.text[:200]}")
                break
            batch = resp.json()
            if not batch:
                break
            members.extend(batch)
            after = batch[-1]["user"]["id"]
            if len(batch) < 1000:
                break

    result = []
    for m in members:
        member_role_ids = m.get("roles", [])
        staff_hits = [rid for rid in member_role_ids if rid in staff_role_ids]
        if not staff_hits:
            continue
        user = m.get("user", {})
        if user.get("bot"):
            continue
        # Top 3 roles by position (skip @everyone, sorted desc)
        member_roles = [roles_by_id[rid] for rid in member_role_ids if rid in roles_by_id]
        member_roles.sort(key=lambda r_: r_["position"], reverse=True)
        top_roles = member_roles[:3]
        # Primary role for subtitle = highest staff role
        staff_roles_sorted = [roles_by_id[rid] for rid in staff_hits]
        staff_roles_sorted.sort(key=lambda r_: r_["position"], reverse=True)
        primary = staff_roles_sorted[0] if staff_roles_sorted else None

        uid = user["id"]
        username = m.get("nick") or user.get("global_name") or user.get("username") or "User"
        if m.get("avatar"):
            avatar_url = f"https://cdn.discordapp.com/guilds/{DISCORD_GUILD_ID}/users/{uid}/avatars/{m['avatar']}.png?size=256"
        elif user.get("avatar"):
            avatar_url = f"https://cdn.discordapp.com/avatars/{uid}/{user['avatar']}.png?size=256"
        else:
            default_idx = int(uid) >> 22 if uid.isdigit() else 0
            avatar_url = f"https://cdn.discordapp.com/embed/avatars/{default_idx % 6}.png"

        result.append({
            "discord_id": uid,
            "username": username,
            "avatar": avatar_url,
            "primary_role": primary["name"] if primary else None,
            "primary_color": primary["color"] if primary else None,
            "roles": [{"name": r_["name"], "color": r_["color"]} for r_ in top_roles],
            "position": primary["position"] if primary else 0,
        })

    result.sort(key=lambda x: x["position"], reverse=True)
    return result


@api_router.get("/team")
async def get_team():
    import time
    now = time.time()
    if now - _team_cache["ts"] < TEAM_CACHE_TTL and _team_cache["data"]:
        return {"members": _team_cache["data"], "cached": True}
    try:
        members = await fetch_discord_team()
        _team_cache["ts"] = now
        _team_cache["data"] = members
        return {"members": members, "cached": False}
    except Exception as e:
        logger.exception("team fetch failed")
        if _team_cache["data"]:
            return {"members": _team_cache["data"], "cached": True, "stale": True}
        raise HTTPException(status_code=500, detail=f"Failed to fetch team: {e}")


# --- Health ---
@api_router.get("/")
async def root():
    return {"message": "FiveM Lynx Panel API", "version": "1.1"}


@api_router.get("/health")
async def health():
    state = await db.bridge_state.find_one({"_id": "state"}, {"_id": 0})
    bridge_connected = False
    if state and state.get("last_sync"):
        try:
            last = datetime.fromisoformat(state["last_sync"])
            bridge_connected = (datetime.now(timezone.utc) - last).total_seconds() < 120
        except Exception:
            pass
    return {
        "status": "ok",
        "bridge_connected": bridge_connected,
        "bridge_state": state,
    }


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"], allow_headers=["*"],
)


@app.on_event("shutdown")
async def shutdown():
    mongo_client.close()
